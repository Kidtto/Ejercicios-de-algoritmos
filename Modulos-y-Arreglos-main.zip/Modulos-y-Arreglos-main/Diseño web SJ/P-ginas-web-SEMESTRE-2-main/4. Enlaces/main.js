'use strict';
//Existen 3 contenedores
var var1;//global
let let1;//local
const const1 = 1;//valor constante
const parrafo1 = document.getElementById("pop");
console.log(parrafo1.textContent);