'use strict';
// for clásico
for(let i=0;i<5;i++){
    console.log(i);
}
let j;
j=5
while(j>0){
    console.log(j);
    j--;
}
//Se ejecuta aunque sea una vez
j=0
do{
    console.log(j);
    j++;
}while(j<10);