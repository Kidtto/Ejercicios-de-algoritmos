'use strict';
// condicionales
let num1 = 12;
if (num1>0){
    console.log('Positivo');
}else{
    if (num1==0){
        console.log('cero');
    }
    else{
        console.log('Negativo');
    }
}