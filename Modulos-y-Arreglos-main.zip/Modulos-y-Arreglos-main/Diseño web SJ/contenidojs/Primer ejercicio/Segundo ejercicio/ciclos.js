'use strict';
//Ciclos para= fro, Mientras= while, repetir hasta= do while
for(let i =0; i<10; i++){
    console.log(i);
}