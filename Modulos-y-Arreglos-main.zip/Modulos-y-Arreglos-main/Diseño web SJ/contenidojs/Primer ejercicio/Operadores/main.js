'use strict';
//Operadores lógicos
/*
> Mayor
< Menor
>= Mayor igual
<= Menor iguak
== Igualdad
=== elemento y tipo
!= No igual
!= No igual elemento y tipo
*/
/**Operadores aritméticos
 * + Suma
 * - Resta
 * / División
 * % Modulo
 * Lógicos booleanos
 * && ||
 */
let num1;
let num2;
num1 = 9;
num2 = '9';
//El ternario: Abreviación del if else
let result;
result = (num1 === num2) ?"Son iguales" :"No son iguales";
console.log(result);

