'use strict';// indica que estamos trabajando en modo estricto
/**
 * Comentarios de bloque
 */

//Declaración de variable so contenedores
/*
var variable1 = 10; //Carácter global
let variable2 = 20; // Ámbito local
const constante1 = 3.14; // Declara constantes

if (true){
    var variable1 = 100;
    let variable2 = 29;
    console.log(variable2)
}

console.log(variable2);*/

//Realizar un programa que lea 2 numeros, los sume y los imprima
let num1=12;
let num2=23;
num1 = prompt("Introduzca un número");
num2 = prompt("Introduzca otro número");
let suma = 0;
suma = parseFloat(num1) + parseFloat(num2);
console.log("El resultado de la suma es: "+suma);
alert("La suma es: "+suma);

