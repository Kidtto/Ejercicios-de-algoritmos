'use strict';
let miarreglo = [2,4,5,65,3, true, '78', "hola mundo"];
let miarreglo2 = new Array(13,21,34,4);
miarreglo.push[56,4,4,3];

for(let i=0; i<miarreglo.length;i++){
    //console.log(miarreglo[i]);
}
//Variaciones del for
for(let j of miarreglo2){
    //console.log(j);  
}

for(let j in miarreglo2){
    //console.log(miarreglo2[j]);  
}

miarreglo2.forEach((e)=>{
    //console.log(e);
});

miarreglo2.forEach(function(e){
    console.log(e);
});