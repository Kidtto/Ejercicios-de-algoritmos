'use strict';
//1.Cadena a arreglo
let cadenadays = 'Lunes_martes_miercoles_jueves_viernes_sabado_domingo';
let array = cadenadays.split("_");
//onsole.log(array);


//2. Buscar
//función anónima ()=>{} Clásica (){}
const result = array.find((e)=>e === 'viernes');
//console.log(result);
const index = array.findIndex((e)=>e === 'Lunes');
//console.log(index);


//3. Comprueba si existe un elemnto dentro de un array devuelve true o false
//console.log(array.includes('lunes'));

//4. Filtrar elementos
let array2=[];
for(let i=0; i<25; i++){
    array2[i]=i+3;
}
console.log(array2);
const result2=array2.filter((e)=>e%2===0);
console.log(result2);

//map, some, every, reduce, concat