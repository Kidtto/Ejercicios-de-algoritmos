'use strict';
let array2=[];
for(let i=0; i<25; i++){
    array2[i]=i+2;
}
//console.log(array2);
//spread Operator ...
//console.log(...array2);
//agregar elementos a un arreglo
array2.push(12,21,33,343,5,7);
//console.log(...array2);
let array3 = [...array2,34,88,3507];
//console.log(...array2);
let result = array2.concat(array3);
//console.log(...result);
let arrayf=[...array2, ...array3, ...result];
console.log(...arrayf);

//Propagación en funciones
let lenguajes=['PHP','Java','JS','Ruby','C#','c++']
const printlenjuages = (len1, len2, len3 ="Assembler", ...len4)=>{
    console.log(`***Los lenguajes TOP*
                ${len1}-${len2}-${len3}-${len4}
                ***********************`);
}
printlenjuages(...lenguajes,'cobol','f#');