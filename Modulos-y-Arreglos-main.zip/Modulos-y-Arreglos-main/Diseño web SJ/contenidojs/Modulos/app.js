'use strcit';
import { suma } from "./calculate.js";
console.log(suma(3,4));
