'use strict';
const addittion = (val1, val2)=>{
    return val1+val2;
}
export { addittion as suma }