'use strict'
let calif;
calif=prompt('Introduzca la calificación')
let mens;
mens ="";
switch(true){
    case calif>=0 && calif <= 2.9:
        //Template String
        mens=`Insuficiente: ${calif}`;
        break;
    case calif>=3 && calif <= 3.5:
        //Template String
        mens=`Regular: ${calif}`;
        break;
    case calif>=3.6 && calif <= 4:
        //Template String
        mens=`Bien: ${calif}`;
        break;
    case calif>=4.1 && calif <= 4.5:
        //Template String
        mens=`Muy bien: ${calif}`;
        break;
    case calif>=4.6 && calif <= 5:
        //Template String
        mens=`Excelente: ${calif}`;
        break;
    default:
        mens=`Sale del rango: ${calif}`;
        break;
}
console.log(mens);
alert('La calificación es: '+mens)